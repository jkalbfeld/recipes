name             'resin'
maintainer       'Jonathan Kalbfeld'
maintainer_email 'jonathan.kalbfeld@thoughtwave.com'
license          'Apache2'
description      'Installs Resin.'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.0.1'


supports 'windows'
