Fresin Cookbook
====================

About
-----
Installs Resin by unziping the file.
